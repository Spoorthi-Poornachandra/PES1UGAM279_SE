import math


def parse_trip(text):
    if not isinstance(text, str):
        raise ValueError("input must be a string")
    parts = text.split(':')
    if len(parts) != 2:
        raise ValueError("expected format cab:km")
    cab, km = parts[0].strip(), float(parts[1])
    if not cab:
        raise ValueError("cab name is empty")
    if not math.isfinite(km) or km < 0:
        raise ValueError("distance must be a finite, non-negative number")
    return cab.title(), km


def fare_average(fares_csv):
    if not isinstance(fares_csv, str):
        raise ValueError("input must be a string")
    values = [int(r) for r in fares_csv.split(',')]
    if any(v < 0 for v in values):
        raise ValueError("fares cannot be negative")
    return sum(values) / len(values)


def payable_fare(text):
    if not isinstance(text, str):
        raise ValueError("input must be a string")
    parts = text.split('|')
    if len(parts) != 2:
        raise ValueError("expected format fare|promo")
    fare, promo = float(parts[0]), float(parts[1])
    if not (math.isfinite(fare) and math.isfinite(promo)) or fare < 0 or promo < 0:
        raise ValueError("fare and promo must be finite, non-negative numbers")
    total = fare * 1.18 - promo
    if not math.isfinite(total):
        raise ValueError("fare too large")
    return max(total, 0)
def main():
    print("==== Running parse_trip ====")
    user_input = input("Enter cab:distance in km (e.g. sedan:12): ")
    result = parse_trip(user_input)
    print("Cab and Distance:", result)

    print("\n==== Running fare_average ====")
    user_input = input("Enter fares as CSV (e.g. 120,95,210): ")
    result = fare_average(user_input)
    print("Average Fare:", result)

    print("\n==== Running payable_fare ====")
    user_input = input("Enter fare|promo (e.g. 250|30): ")
    result = payable_fare(user_input)
    print("Payable Fare:", result)

if __name__ == "__main__":
    main()
