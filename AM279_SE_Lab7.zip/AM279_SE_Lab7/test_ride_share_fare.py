import math
from hypothesis import given, strategies as st
from ride_share_fare import parse_trip, fare_average, payable_fare


def check_no_crash(func, s):
    try:
        return func(s)
    except ValueError:
        return None
    except Exception as e:
        assert False, f"{func.__name__} crashed with: {e!r}"


@given(st.text() | st.none())
def test_parse_trip_no_crash(s):
    check_no_crash(parse_trip, s)


@given(st.text() | st.none())
def test_fare_average_no_crash(s):
    check_no_crash(fare_average, s)


@given(st.text() | st.none())
def test_payable_fare_no_crash(s):
    check_no_crash(payable_fare, s)


@given(st.text(), st.floats(allow_nan=True, allow_infinity=True))
def test_parse_trip_distance_valid(cab, km):
    result = check_no_crash(parse_trip, f"{cab}:{km}")
    if result is not None:
        assert math.isfinite(result[1]) and result[1] >= 0


@given(st.lists(st.integers(min_value=0, max_value=100000), min_size=1))
def test_fare_average_is_exact_mean(fares):
    result = fare_average(",".join(map(str, fares)))
    assert abs(result - sum(fares) / len(fares)) < 1e-6


@given(st.floats(allow_nan=True, allow_infinity=True),
       st.floats(allow_nan=True, allow_infinity=True))
def test_payable_fare_never_negative_or_nan(fare, promo):
    result = check_no_crash(payable_fare, f"{fare}|{promo}")
    if result is not None:
        assert math.isfinite(result) and result >= 0